import express from "express"
import {showcont,addcont} from "../mysql/controles.js"
const rotas=express.Router()
rotas.get("/showcont",showcont);
rotas.post("/addcont",addcont);
export default rotas;