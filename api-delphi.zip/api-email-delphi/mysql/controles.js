import {db} from "../db.js"

export const showcont=(_,res)=>{
const q="SELECT * FROM idecontato";
db.query(q,(err,data)=>{
if (err){
    return res.status(500).json({ error:"erro ao busca contato"})
}
return res.status(200).json({data})
})

}

export const addcont=(req,res)=>{
    const q="CALL inseriform(?,?,?,?)";
    const values=[
        req.body.nome,
        req.body.email,
        req.body.assunto,
        req.body.conteudo
    ];
    console.log(values);
    db.query(q,values,(err)=>{
    if (err){
        console.log(err)
        return res.status(500).json({ error:"erro ao enviar respostas"})
    }
    return res.status(200).json("resposta registrada")
    })
    
    }

